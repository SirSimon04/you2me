/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EJB;

import Entity.Account;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author 
 */
@Stateless
@LocalBean
public class AccountFacade {

    @PersistenceContext
    private EntityManager em;
    
    public Account get(int id){
        return em.find(Account.class, id);
    }
    
    public Account getByName(String name) {
        return em.createNamedQuery(Account.class.getSimpleName()+".findByName", Account.class).setParameter("name", name).getSingleResult();
    }
    
    public void create(String name, String pwHash) {
        Account acc = new Account();
        acc.setName(name);
        acc.setPasswordhash(pwHash);
        em.persist(acc);
    }    
}
