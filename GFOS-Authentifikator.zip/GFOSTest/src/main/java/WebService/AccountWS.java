/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package WebService;

import EJB.AccountFacade;
import Entity.Account;
import Utilities.Hasher;
import Utilities.Tokenizer;
import com.google.gson.Gson;
import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

/**
 *
 * @author 
 */
@Path("/account")
@Stateless
@LocalBean
public class AccountWS {
    
    @EJB
    private AccountFacade accountFacade;
    @EJB
    private Hasher hasher;
    @EJB
    private Tokenizer tokenizer;
           
    @GET
    @Path("/createTest")
    @Produces(MediaType.APPLICATION_JSON)
    public String createTest(){
        String NAME = "Mustermann";
        String PASSWORD = "geheim";
        accountFacade.create(NAME, hasher.convertStringToHash(PASSWORD));
        // Überprüfen, ob es funktioniert hat:
        Gson parser = new Gson();
        Account ergebnisAusDB = accountFacade.getByName("Mustermann");
        return parser.toJson(ergebnisAusDB);
    }
    
    @GET
    @Path("/loginTest/{pw}")
    @Produces(MediaType.TEXT_PLAIN)
    public String loginTest(@PathParam("pw") String pw) {
        String NAME ="Mustermann";
        String PASSWORD = pw;
        Account acc = accountFacade.getByName(NAME);
        System.out.println(acc.getPasswordhash());
        System.out.println(hasher.convertStringToHash(PASSWORD));
        if(hasher.convertStringToHash(PASSWORD).equals(acc.getPasswordhash())) {
            return "{\"token\": \"" + tokenizer.createNewToken(NAME) + "\"}";
        }
        else {
            return "Benutzername oder Passwort falsch";
        }
    }
    
    @GET
    @Path("/topsecret/{token}")
    @Produces(MediaType.TEXT_PLAIN)
    public String testToken(@PathParam("token") String token) {
        if(tokenizer.verifyToken(token).equals("")) {
            return "Kein gültiges Token.";
        }
        else {
            String name = tokenizer.getUser(token);
            return "Herzlich willkommen " + name +". Dein Token ist noch gültig.";
        }
    }
}