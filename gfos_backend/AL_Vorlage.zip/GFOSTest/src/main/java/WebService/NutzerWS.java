/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package WebService;

import EJB.NutzerEJB;
import Entity.Nutzer;
import com.google.gson.Gson;
import java.util.List;
import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Consumes;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import com.google.gson.JsonSyntaxException;

/**
 *
 * @author Simon
 */
@Path("/nutzer")
@Stateless
@LocalBean
public class NutzerWS {
    
    @EJB
    private NutzerEJB nutzerEJB;
    
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public String getAll(){
        Gson parser = new Gson();
        List<Nutzer> alleNutzer = nutzerEJB.getAll();
        return parser.toJson(alleNutzer);
    }
    
    @GET
    @Path("/test")
    @Produces(MediaType.TEXT_PLAIN)
    public String test() {
        return ("test succesful1");
    }

    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public String get(@PathParam("id") int id) {
        Gson parser = new Gson();
        return parser.toJson(nutzerEJB.get(id));
    }
    
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.TEXT_PLAIN)
    public boolean create(String jsonStr) {
        Gson parser = new Gson();
        try {
            Nutzer neuePizza = parser.fromJson(jsonStr, Nutzer.class);
            nutzerEJB.add(neuePizza);
            return true;
        }
            catch(JsonSyntaxException e) {
            return false;
        }
        }
    
}